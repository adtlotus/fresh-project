Kalau mau memakai kode, rename folder.
Hilangkan nomor bab, hilangkan bagian _18_x_x.
Jadi tinggal folder "oopmvc". Nah folder "oopmvc" inilah yang bisa 
di-copy dan replace ke C:/wamp/www.

Nomor bab hanya dipakai untuk menunjukkan step-step, tempat sub-bab dimana kode itu dibahas.