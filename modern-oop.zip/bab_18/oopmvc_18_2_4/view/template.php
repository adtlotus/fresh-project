<!-- view/template.php -->
<!DOCTYPE html>
<html>
    <head>
        <title><?= $judul ?></title>
    </head>
    <body>
        <?= $isi ?>
    </body>
</html>