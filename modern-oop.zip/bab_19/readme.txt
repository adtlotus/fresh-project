Aplikasi ini adalah aplikasi "jadi" yang dibahas di bab 19.

Untuk mengujinya:

1) Masukkan folder "oopmvc" ke folder "www" atau "htdocs".

2) Import database pada file "db_oopmvc".

3) Pada browser, ketik URL: http://localhost/oopmvc/index.php/anggota.

4) Enjoy it!